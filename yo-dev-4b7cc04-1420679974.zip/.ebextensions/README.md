##ebextensions

This repository keeps the common Elastic Beanstalk file-based customizations under version control.  The `gantree` project will soon generate all these files as part of the deploy artifacts.

###02-aws.config
Installs the `/root/get-authorized-keys.sh` script to download the `authorized_keys` file from S3. 

###03-extend_timeout.config
Extends the boot up timeout so the Docker container has plenty of time to download and build.

###04-add-docker-utilities.config
Creates the ```docker-enter``` script so that you can easily nsenter into a running Docker container.

####05-add-cron-job-refresh-authorized-keys.config
Adds a cron job that calls the `/root/get-authorized-keys.sh` script to to download the `authorized_keys` file from S3 every 5 minutes.
